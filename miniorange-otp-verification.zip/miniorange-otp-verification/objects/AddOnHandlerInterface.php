<?php
namespace OTP\Objects;

interface AddOnHandlerInterface
{
    
    function setAddonKey();         function setAddOnDesc();        function setAddOnName();        function setSettingsUrl();  }