<?php

global $wpfts_db_updates;

$wpfts_db_updates = array(
	'1.14.22' => array(
		'text' => __('<ul><li>Big update: lots of functions was moved from the Pro version to the Free WPFTS Version</li>
						<li>Some interface bugs were fixed</li>
						<li>Relevance formula was completely rebuilt</li>
						<li>Reindex algorithm was sufficiently improved (now 5 times faster!)</li>
						<li>Word max length was increased to 255 characters</li>
					</ul>', 'wpfts_lang'),
		'is_rebuild' => true,
	),
);

