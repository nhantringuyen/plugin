<?php

echo'	<div class="mo_registration_divided_layout">
            <div class="mo_registration_table_layout">
                <table style="width:100%">
                    <tr>
                        <td><span class="dashicons icon404 dashicons-warning"></span></td>
                     </tr>
                    <tr>
                        <td>
                            <div style="font-size:100px;padding-top:9%;padding-left: 40%;">Oops!</div>
                            <div style="font-size:20px;padding-top:17%;padding-left: 5%;">We can\'t seem to find the page you are looking for.</div>
                            <div style="font-size:15px;padding-top:1%;padding-left: 5%;">Error Code: 400</div>  
                         </td>
                     </tr>
                </table>
            </div>
        </div>';