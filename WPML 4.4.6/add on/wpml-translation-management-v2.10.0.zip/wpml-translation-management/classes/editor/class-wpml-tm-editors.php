<?php

class WPML_TM_Editors {
	const ATE  = 'ate';
	const WPML = 'wpml';
	const WP   = 'wp';
	const NONE = 'none';
}