<?php
/**
 * Integrate with Visual composer
 *
 * @since 2.1
 * @package Marvelous Hover Effects
 */
class Marvelous_VC_Integrate {
  /**
   * Parent plugin class
   *
   * @var    VCMarvelousHover
   * @since  2.1
   */
  protected $plugin = null;

  /**
   * Constructor
   *
   * @since  2.1
   * @param  VCMarvelousHover $plugin Main plugin object.
   * @return void
   */
  public function __construct( $plugin ) {
    $this->plugin = $plugin;

    if ( marvelous_has_visual_commposer() ) {
      $this->integrateWithVisualComposer();
    }
  }

  public function integrateWithVisualComposer() {
    vc_add_shortcode_param( 'marvelous_class', array( $this, 'classFieldSetting' ) );
    vc_add_shortcode_param( 'marvelous_id', array( $this, 'idFieldSetting' ) );
    vc_add_shortcode_param( 'marvelous_tutorial', array( $this, 'tutorialSetting' ) );
  }

  public function classFieldSetting( $settings, $value ) {
    $value = 'marvelous_custom_class_' . uniqid( rand( 8, 10 ) );

    return
      '<div class="my_param_block"><input name="' .
      esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput ' .
      esc_attr( $settings['param_name'] ) . ' ' .
      esc_attr( $settings['type'] ) . '_field" type="hidden" value="' . esc_attr( $value ) .
      '" /></div>';
  }

  public function idFieldSetting( $settings, $value ) {
    $value = 'marvelous_id_' . uniqid( rand( 8, 10 ) );

    return '<div class="vc_param-vc-grid-id"><input name="'
           . $settings['param_name']
           . '" class="wpb_vc_param_value wpb-textinput '
           . $settings['param_name'] . ' ' . $settings['type'] . '_field" type="hidden" value="'
           . $value . '" /></div>';
  }

  public function tutorialSetting( $settings, $value ) {
    return
      '<div class="marvelous-tutorial-block"><h4 class="wpb_vc_param_value "><a href="'
      . $settings['value'] . '" target="_blank"><span class="dashicons dashicons-editor-help"></span></a></h4></div>';
  }
}

