<?php

class WPML_ACF_Post_Object_Field extends WPML_ACF_Field {

	public function field_type() {
		return "post_object";
	}

}
