<?php foreach ( $settings['value'] as $k => $v ) { ?>
  <input
    type="checkbox"
    id="<?php echo $settings['param_name'] ?>"
    name="<?php echo $settings['param_name'] ?>"
    value="<?php echo $v ?>"
  />
  <label for="<?php echo $settings['param_name'] ?>"><?php echo $k ?></label>
<?php } ?>
