<input
  type="text"
  id="<?php echo $settings['param_name'] ?>"
  name="<?php echo $settings['param_name'] ?>"
  class="popup_image"
  value=""
/>
<input class="upload_button" type="button" value="Upload file" id="popup_image_button">
