<?php

namespace OTP\Objects;

class VerificationType
{
    const EMAIL = 'email';
    const PHONE = 'phone';
    const BOTH = 'both';
    const EXTERNAL = 'external';
    const TEST = 'test';
}