<?php

if(! defined( 'ABSPATH' )) exit;

define('MCM_DIR', plugin_dir_path(__FILE__));
define('MCM_URL', plugin_dir_url(__FILE__));
define('MCM_VERSION', '1.0.0');
define('MCM_SHORTCODE_SMS_JS', MCM_URL . 'includes/js/shortcodesms.min.js');
define('MCM_SHORTCODE_EMAIL_JS', MCM_URL . 'includes/js/shortcodeemail.min.js');
