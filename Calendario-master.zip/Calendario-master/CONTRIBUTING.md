Intorduction
=========
**Please follow these rules when creating an issue**
+ First and foremost do not create pull request against the `gh-pages` branch.
+ Naturally if you have doubt or new to the programming world, we will help when after you have done the following tasks. **First try to Google the solutions, find similar problems, issues and if you don't find anything relevant then ask.**
+ Feature request are welcomed, but first check if they have been implemented, and if they have been put up as a **milestone for the next version.**
+ Pull requests should **pass** our tests and should have **less verbose code**, only then they will be accepted.
