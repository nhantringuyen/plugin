<?php

class WPML_TP_Exception extends Exception {

}
