<?php

echo' 	<div class="mo_otp_form" id="'.get_mo_class($handler).'">
 	        <input type="checkbox" '.$disabled.' 
                id="wc_social" 
                class="app_enable" 
                name="mo_customer_validation_wc_social_login_enable" 
                value="1"
			    '.$wc_social_login.' /><strong>'.$form_name.'</strong>';

echo' </div>';

