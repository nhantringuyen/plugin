<?php
namespace DuplicatorPro\Guzzle\Common\Exception;

defined("ABSPATH") or die("");

class UnexpectedValueException extends \UnexpectedValueException implements GuzzleException {}
