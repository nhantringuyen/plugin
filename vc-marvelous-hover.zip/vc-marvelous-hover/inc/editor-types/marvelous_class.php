<?php
  $value = 'marvelous_custom_class_' . uniqid( rand( 8, 10 ) );
?>
<input
  type='hidden'
  name="<?php echo $settings['param_name'] ?>"
  id="<?php echo $settings['param_name'] ?>"
  value="<?php echo $value ?>"
/>
