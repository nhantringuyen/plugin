<?php

require_once( __DIR__ . '/class-itsec-security-check-pro.php' );
$itsec_security_check_pro = new ITSEC_Security_Check_Pro();
$itsec_security_check_pro->run();
