<?php
ITSEC_Response::reload_module( 'security-check' );
ITSEC_Response::reload_module( 'global' );
