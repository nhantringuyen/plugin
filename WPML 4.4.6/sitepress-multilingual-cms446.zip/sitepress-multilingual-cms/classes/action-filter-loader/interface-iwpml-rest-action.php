<?php
/**
 * @author OnTheGo Systems
 */
interface IWPML_REST_Action extends IWPML_Action {
}
