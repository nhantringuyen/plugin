<?php
if (!defined('ABSPATH')) {
    exit('Direct\'s not allowed');
}
/*add_filter( 'cf7d_entry_value', 'cf7d_fix_value_array_func', 10, 2 );
function cf7d_fix_value_array_func($val, $key) {
    $val = str_replace("\n", "", $val);
    return $val;
}
*/