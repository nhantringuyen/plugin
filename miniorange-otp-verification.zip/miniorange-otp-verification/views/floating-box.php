<?php 

echo '<div class="mo_registration_settings_save_float static">
			<h2>'.mo_("Save your settings.").'</h2>
			<input type="button" id="ov_settings_button_float"  
						value="'.mo_("Save").'" style="margin-bottom:2%;"'.$disabled.'
						class="button button-primary button-large" />
		</div>';