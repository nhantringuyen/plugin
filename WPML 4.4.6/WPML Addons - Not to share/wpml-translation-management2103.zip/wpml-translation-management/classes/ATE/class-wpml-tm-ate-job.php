<?php
/**
 * @author OnTheGo Systems
 */
class WPML_TM_ATE_Job {

	const ATE_JOB_CREATED = 0;
	const ATE_JOB_IN_PROGRESS = 1;
	const ATE_JOB_TRANSLATED = 6;
	const ATE_JOB_DELIVERING = 7;
	const ATE_JOB_DELIVERED = 8;

}
