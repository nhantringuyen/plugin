=== MailChimp for WordPress Multilingual ===
Tags: wpml, mailchimp
Requires at least: 4.1
Tested up to: 4.9.6
Requires PHP: 5.3
Stable tag: 0.0.3

Helps you to translate MailChimp4WP forms and widgets.

== Changelog ==

= 0.0.3 =
* Minor fixes for multilingual widget

= 0.0.2 =
* Added support for MC4WP form widget

= 0.0.1 =
* Added support for WPML language switcher on mc4wp edit form screen
* Added multilingual helper for mc4wp shortcode