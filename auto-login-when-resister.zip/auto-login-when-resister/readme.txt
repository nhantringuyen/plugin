===Enable/Disable Auto Login when Register ===
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=amu02.aftab@gmail.com&item_name=Auto+Login+After+Register
Tags: registration, signup, auto login after registration 
Contributors: amu02aftab
Author: amu02aftab
Tested up to: 5.0.3
License: GPLv2
Requires at least: 3.5.0
Stable tag: 1.0

== Description ==
The plugin provides feature to enable/disable auto login when user register 
 
<strong>Feature</strong>

* Enable /disable auto login from admin 


== Screenshots ==

1. Back End Auto Login when Resister setting 


== Frequently Asked Questions ==
1. No technical skills needed.

== Changelog ==
This is first version no known errors found

== Upgrade Notice == 
This is first version no known notices yet

== Installation ==
1. Upload the folder "auto-login-when-resister" to "/wp-content/plugins/"
2. Activate the plugin through the "Plugins" menu in WordPress
3. Enable/ disable 'Auto Login When Register' setting by going WP-admin -> Settings ->Auto Login When Register 



