<div class="colorSelector"><div style=""></div></div>
<input
  type="text"
  name="<?php echo $settings['param_name'] ?>"
  id="<?php echo $settings['param_name'] ?>"
  value=""
/>
<script type="text/javascript">
  colorPicker();
</script>
