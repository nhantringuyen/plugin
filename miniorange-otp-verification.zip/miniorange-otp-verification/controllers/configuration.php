<?php

use OTP\Helper\GatewayFunctions;

$gateway = GatewayFunctions::instance();
$gateway->showConfigurationPage($disabled);